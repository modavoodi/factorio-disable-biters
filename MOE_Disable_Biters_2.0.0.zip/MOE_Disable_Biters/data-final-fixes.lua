
for _, ent in pairs(data.raw["unit-spawner"]) do
    if ent and ent.autoplace then
        ent.autoplace.probability_expression = '0'
    end
end

for _, ent in pairs(data.raw.turret) do
    if ent.subgroup == "enemies" and ent and ent.autoplace then
        ent.autoplace.probability_expression = '0'
    end
end
